/*
 * adc_ad5592.h
 *
 */

#ifndef ADC_AD5592_H_
#define ADC_AD5592_H_

void AD5592_reset();
void AD5592_write_ctrl(unsigned char addr, unsigned short value);
void AD5592_write_dac(unsigned char addr, unsigned short value);
unsigned short AD5592_readback(unsigned char readback_reg);
unsigned short AD5592_dac_readback(unsigned char dac_channel);

#endif /* ADC_AD5592_H_ */
