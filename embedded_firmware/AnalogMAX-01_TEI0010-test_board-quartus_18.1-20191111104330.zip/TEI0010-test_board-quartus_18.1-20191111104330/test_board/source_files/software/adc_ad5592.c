/**************************************************************************
 *
 * smoke_detector.c
 *
 * ADPD188BI -> slave address: 0x64
 *
**************************************************************************/

#include "adc_ad5592.h"
#include "system.h"

void AD5592_reset(){
	unsigned char wdata[2],rdata[2];
	wdata[0] = 0x7D;
	wdata[1] = 0xAC;
	alt_avalon_spi_command(SPI_BASE, 2, 2, wdata, 0, rdata, 0);
	usleep(300);
}

void AD5592_write_ctrl(unsigned char addr, unsigned short value){
	unsigned char wdata[2],rdata[2];
	wdata[0] = ((addr << 11) + (value & 0xfff))>> 8;
	wdata[1] = ((addr << 11) + (value & 0xfff));
	alt_avalon_spi_command(SPI_BASE, 2, 2, wdata, 0, rdata, 0);
}

void AD5592_write_dac(unsigned char addr, unsigned short value){
	unsigned char wdata[2],rdata[2];
	wdata[0] = ((addr << 12) + (value & 0xfff) | 0x8000)>> 8;
	wdata[1] = ((addr << 12) + (value & 0xfff) | 0x8000);
	alt_avalon_spi_command(SPI_BASE, 2, 2, wdata, 0, rdata, 0);
}

unsigned short AD5592_readback(unsigned char readback_reg){
	unsigned char wdata[2],rdata[2];
	unsigned short readback=0;
	wdata[0] = 0x38;
	wdata[1] = (readback_reg | 0x10) << 2;
	alt_avalon_spi_command(SPI_BASE, 2, 2, wdata, 0, rdata, 0);
	alt_avalon_spi_command(SPI_BASE, 2, 0, wdata, 2, rdata, 0);
	readback = ((rdata[0]<<8) + rdata[1])&0xfff;
	return readback;
}

unsigned short AD5592_dac_readback(unsigned char dac_channel){
	unsigned char wdata[2],rdata[2];
	unsigned short dac_readback;
	wdata[0] = 0x08;
	wdata[1] = dac_channel | 0x18;
	alt_avalon_spi_command(SPI_BASE, 2, 2, wdata, 0, rdata, 0);
	alt_avalon_spi_command(SPI_BASE, 2, 0, wdata, 2, rdata, 0);
	dac_readback = (rdata[0]<<8) + rdata[1];
	return dac_readback;
}

