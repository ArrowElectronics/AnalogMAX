/*
 * smoke_detector.h
 *
 */

#ifndef SMOKE_DETECTOR_H_
#define SMOKE_DETECTOR_H_

void ADPD_init();
void ADPD_write_reg(unsigned char reg_addr,unsigned short data);
void ADPD_read_reg8(unsigned char reg_addr, int *data);
void ADPD_read_reg16(unsigned char reg_addr, int *data);
void ADPD_read_fifo(unsigned char reg_addr,int *slot_a,int *slot_b);

#endif /* SMOKE_DETECTOR_H_ */
