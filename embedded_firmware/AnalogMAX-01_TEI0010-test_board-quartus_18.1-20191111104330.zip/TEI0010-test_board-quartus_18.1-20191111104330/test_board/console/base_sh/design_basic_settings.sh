# # --------------------------------------------------------------------
# # --   *****************************
# # --   *   Trenz Electronic GmbH   *
# # --   *   Holzweg 19A             *
# # --   *   32257 B�nde             *
# # --   *   Germany                 *
# # --   *****************************
# # --------------------------------------------------------------------
# # --$Autor: D�ck, Thomas $
# # --$Email: t.dueck@trenz-electronic.de $
# # --$Create Date: 2019/11/07 $
# # --$Modify Date: 2019/11/07 $
# # --$Version: 1.0 $
# # 	-- intial release 18.1
# # --------------------------------------------------------------------
# # Additional description on: https://wiki.trenz-electronic.de/display/PD/Project+Delivery+-+Intel+devices
# # --------------------------------------------------------------------
# # Important Settings:
# # -------------------------
# --------------------
# Set Quartus Installation path:
#    -The scripts search for Quartus software on this paths:
#    -Quartus (recommend used for project creation and programming): %QUADIR%\%QUARTUS_VERSION%\
# -Important Note: Check if Quartus default install path use upper or lower case
export QUADIR=~/intelFPGA_lite
# -Attention: These scripts support only the predefined Quartus Version. 
export QUARTUS_VERSION=18.1
# --------------------
# # --------------------------------------------------------------------
# # Optional Settings:
# # -------------------------
# --------------------
# Do not close shell after processing
#  -Example: @set DO_NOT_CLOSE_SHELL=1, Shell will not be closed
#            @set DO_NOT_CLOSE_SHELL=0, Shell will be closed automatically
export DO_NOT_CLOSE_SHELL=0
# --------------------
# Set device FPGA family and device of the project which should be created
#    -Available Numbers: (you can use ID,PRODID from \board_files\TEIxxxx_devices.csv list) or
# 	 special name "LAST_ID" to get the board with the highest ID in the *.csv list
#    -variable is used for project creation and programming
#    -Example: set PARTNUMBER=TEI0001-02-16-C8 || @set PARTNUMBER=1
export PARTNUMBER=LAST_ID
# --------------------

