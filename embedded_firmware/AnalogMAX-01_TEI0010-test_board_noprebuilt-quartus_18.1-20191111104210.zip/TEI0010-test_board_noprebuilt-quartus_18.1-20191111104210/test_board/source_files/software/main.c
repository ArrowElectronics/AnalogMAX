/*
 * test_board
 *
 * main.c
 *
 */


#include "system.h"
#include "unistd.h"
#include "stdio.h"
#include "altera_avalon_pio_regs.h"
#include "altera_avalon_spi.h"

#include "smoke_detector.h"
#include "adc_ad5592.h"

void init_g_sen();
void init_temp_sen();

int main()
{
	unsigned char wdata[2];
	unsigned char rdata[3];
	unsigned char led_out = 0x18;
	int temp;
	int id = 0;
	int slot_a = 0;
	int slot_b = 0;
	int adc_temp = 0;
	int adc = 0;

	alt_8 y_value = 0;			// create buffer for filtering
	alt_8 y_value_1 = 0;
	alt_8 y_value_2 = 0;
	alt_8 y_value_3 = 0;
	alt_8 y_value_4 = 0;
	alt_8 y_value_5 = 0;
	alt_8 mode = 0;
	alt_8 n_mode = 0x00;
	alt_u8 wb_send[1];
	alt_u8 wb_get[20];

	IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, 0x55); // reset mode counter
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, 0x00);

	printf("\n\n==================== test_board ====================\n");
	printf("Toggle between following modes by pressing the user\n");
	printf("button:\n\n");
	printf("1. Spirit level\n");
	printf("2. Winbond SPI flash memory test\n");
	printf("3. Temperature measurement\n");
	printf("4. Smoke detector\n");
	printf("5. ADC\n");
	printf("\nCurrent mode:\n");

	while (1){
		mode = IORD_ALTERA_AVALON_PIO_DATA(PIO_MODE_BASE);

		if (mode != n_mode){
			switch(mode){
			case 0x01: printf("\nMode = %d => Spirit level\n", mode);
				init_g_sen();					// initialize g-sensor
				break;
			case 0x02: printf("Mode = %d => Winbond SPI flash memory test\n", mode);
				wb_send[0]=0x9f; // jedec id address
				alt_avalon_spi_command(SPI_FLASH_BASE, 0, 1, wb_send, 3, wb_get, 0);
				printf("	-> Read JEDEC ID: ");
				for (int i=0; i < 3; i++) {
					printf("%x", wb_get[i]);
				}
				printf("\n");

				wb_send[0]=0x4b; // unique id address
				alt_avalon_spi_command(SPI_FLASH_BASE, 0, 1, wb_send, 15, wb_get, 0);
				printf("	-> Read Unique ID: ");
				for (int i=4; i < 12; i++) {
					printf("%x", wb_get[i]);
				}
				printf("\n");
			break;
			case 0x03:
				printf("Mode = %d => Temperature measurement\n", mode);
				init_temp_sen();				// initialize temperature sensor
				break;
			case 0x04: printf("\n\nMode = %d => Smoke detector\n", mode);
				ADPD_init();					// initialize smoke detector
				ADPD_read_reg8(0x08,&id);		// read device id (0x16)
				printf(" - Device ID: 0x%x\n",id);
				printf(" - slot_a (blue led):  |  slot_b (IR led):\n");
				break;
			case 0x05: printf("\n\nMode = %d => ADC\n", mode);
				ADPD_write_reg(0x0F,0x0001);	// Software reset (smoke detector) -> device returns to standby mode

				AD5592_reset();
				AD5592_write_ctrl(0x03, 0x30);   // ADC and DAC range VREF*2
				AD5592_write_ctrl(0x0b, 0x200);  // Power Down/reference control: enable -> internal reference

				// read and calculate temperature
				AD5592_write_ctrl(0x02, 0x100);	// ADC sequence: enable -> REP, Temperature
				alt_avalon_spi_command(SPI_BASE, 2, 0, wdata, 2, rdata, 0); // read temperature
				adc_temp = ((rdata[0]<<8) + rdata[1]) & 0xfff;
				adc_temp = 25 + ((adc_temp - 410)/2.654);
				printf(" - Device temperature: %i C\n", adc_temp);
				AD5592_write_ctrl(0x02, 0x000); 	// ADC sequence: none

				// ADC0
				AD5592_write_ctrl(0x04, 0x01);  			// ADC Config: enable IO0
				AD5592_write_ctrl(0x02, 0x01 | 0x200);  	// ADC SEQUENCE: ADC0, Repeat
				break;
			default: printf("\nError: Select mode failed\n");	break;
			}
			n_mode = mode;
		}

		if (mode == 0x01){ 		// accelerometer
			wdata[0]=0x0B;		// set axis register
			wdata[1]=0x08; 		// x-axis data

			alt_avalon_spi_command(SPI_BASE, 0, 2, wdata, 1, rdata, 0);	// read axis data

			y_value_5 = y_value_4;	// calculate average
			y_value_4 = y_value_3;
			y_value_3 = y_value_2;
			y_value_2 = y_value_1;
			y_value_1 = rdata[0]-0xf9; // Offset: 0xf9
			y_value = (y_value_1 + y_value_2 + y_value_3 + y_value_4 + y_value_5) / 5;

			// determine LED setting according to y-axis value
			if (y_value >= 16) 					led_out = 0x01;
			if (y_value >= 12 && y_value <  16) led_out = 0x02;
			if (y_value >=  8 && y_value <  12) led_out = 0x04;
			if (y_value >=  4 && y_value <   8) led_out = 0x08;
			if (y_value >  -4 && y_value <   4) led_out = 0x18;
			if (y_value >  -8 && y_value <= -4) led_out = 0x10;
			if (y_value > -12 && y_value <= -8) led_out = 0x20;
			if (y_value > -16 && y_value <=-12) led_out = 0x40;
			if (y_value <=-16) 					led_out = 0x80;

			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, led_out);
			usleep(10000);
		}

		if (mode == 0x03){		// temperature sensor
			wdata[0] = 0x50;	//set temperature register
			wdata[1] = 0x00;

			alt_avalon_spi_command(SPI_BASE, 1, 1, wdata, 2, rdata, 1);	// read temperature data
			temp =(rdata[0]<<8) + rdata[1];

			if(temp >= 32768){	//calculate temperature
				temp = (temp-65536)/128;
			}
			else{
				temp /=128;
			}
			printf("\r - Temperature: %03i",temp);

			// determine LED setting according to temperature value (10�C - 45�C)
			if (temp >= 43) 			 led_out = 0xFF;
			if (temp >= 39 && temp < 43) led_out = 0x7F;
			if (temp >= 35 && temp < 39) led_out = 0x3F;
			if (temp >= 31 && temp < 35) led_out = 0x1F;
			if (temp >= 27 && temp < 31) led_out = 0x0F;
			if (temp >= 23 && temp < 27) led_out = 0x07;
			if (temp >= 19 && temp < 23) led_out = 0x03;
			if (temp >= 15 && temp < 19) led_out = 0x01;
			if (temp <  15) 			 led_out = 0x00;

			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, led_out);
			usleep(10000);
		}

		if (mode == 0x04){		//smoke detector
			ADPD_read_fifo(0x60, &slot_a, &slot_b);	// read fifo
			slot_a /= 1024;
			slot_b /= 1024;
			printf("\r          %02i           |         %02i     ",slot_a, slot_b);

			// determine LED setting according to slot_a (blue led)
			if (slot_a >= 56) 			 	 led_out = 0xFF;
			if (slot_a >= 48 && slot_a < 56) led_out = 0x7F;
			if (slot_a >= 40 && slot_a < 48) led_out = 0x3F;
			if (slot_a >= 32 && slot_a < 40) led_out = 0x1F;
			if (slot_a >= 24 && slot_a < 32) led_out = 0x0F;
			if (slot_a >= 16 && slot_a < 24) led_out = 0x07;
			if (slot_a >=  8 && slot_a < 16) led_out = 0x03;
			if (slot_a >=  1 && slot_a < 8) led_out = 0x01;
			if (slot_a <   1) 			 	 led_out = 0x00;

			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, led_out);
			usleep(10000);
		}

		if (mode == 0x05){		// adc
			alt_avalon_spi_command(SPI_BASE, 2, 0, wdata, 2, rdata, 0);
			adc = ((rdata[0]<<8) + rdata[1])&0xfff;			// NOTE: disable ADC sequence!
			//adc = 2*2.5*adc/4096;							// mV -> V
			printf("\r - ADC0 (Pin AIN0) result: %i mV    ", adc);

			// determine LED setting according to voltage value (0 mV - 20000 mV)
			if (adc >= 2000) 				led_out = 0xFF;
			if (adc >= 1600 && adc < 1800) 	led_out = 0x7F;
			if (adc >= 1400 && adc < 1600) 	led_out = 0x3F;
			if (adc >= 1200 && adc < 1400) 	led_out = 0x1F;
			if (adc >= 1000 && adc < 1200) 	led_out = 0x0F;
			if (adc >=  800 && adc < 1000)  led_out = 0x07;
			if (adc >=  600 && adc <  800)  led_out = 0x03;
			if (adc >=  300 && adc <  600)	led_out = 0x01;
			if (adc <   100)				led_out = 0x00;

			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LED_BASE, led_out);
			usleep(100000);
		}
	}
	return 0;
}

void init_g_sen()
{
	unsigned char wdata[2];
	unsigned char rdata[3];

	wdata[0]= 0x0A;				// write command
	wdata[1]= 0x2C;				// Adress Filter Control Register
	wdata[2]= 0x11;				// 2g, bandwidth antialiasing filter = 1/4, 25Hz
	alt_avalon_spi_command(SPI_BASE, 0, 3, wdata, 0, rdata, 0);

	wdata[0]= 0x0A;				// write command
	wdata[1]= 0x2D;				// Adress Power Control Register
	wdata[2]= 0x02;				// Select Measurement mode
	alt_avalon_spi_command(SPI_BASE, 0, 3, wdata, 0, rdata, 0);
}

void init_temp_sen()
{
	unsigned char wdata[4];
	unsigned char rdata[2];

	wdata[0] = 0xFF;			// reset temperature sensor
	wdata[1] = 0xFF;
	wdata[2] = 0xFF;
	wdata[3] = 0xFF;
	alt_avalon_spi_command(SPI_BASE, 1, 4, wdata, 0, rdata, 1);
	usleep(1000);

	wdata[0] = 0x08;			// configuration register
	wdata[1] = 0x80;			// set 16 bit resolution
  alt_avalon_spi_command(SPI_BASE, 1, 2, wdata, 0, rdata, 1);
}
