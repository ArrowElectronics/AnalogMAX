/**************************************************************************
 *
 * smoke_detector.c
 *
 * ADPD188BI -> slave address: 0x64
 *
**************************************************************************/

#include "smoke_detector.h"
#include "system.h"

void ADPD_init(){
	I2C_init(I2C_BASE,ALT_CPU_FREQ,1000);

	ADPD_write_reg(0x00 ,0x1000);	// reset: 0x0000/ Number of available bytes to be read from FIFO (bit[15:8])
	ADPD_write_reg(0x02 ,0x0005);	// reset: 0x0000/ enable gpio0 + set active low
	ADPD_write_reg(0x06 ,0x0F00);	// reset: 0x0000/ FIFO length threshold (bit[13:8])
	ADPD_write_reg(0x11 ,0x3065);	// reset: 0x1000/ Channel A,B, Average, 16 bit sum of channels
	ADPD_write_reg(0x12 ,0x0050);	// reset: 0x0028/ sampling frequency= 100 Hz
	ADPD_write_reg(0x14 ,0x0117);	// reset: 0x0541/led1 pulse during time slot a/ led3 pulse during time slot b
	ADPD_write_reg(0x15 ,0x0220);	// reset: 0x0600/averaging factor time slot a/b = 4
	ADPD_write_reg(0x18 ,0x1F00);	// reset: 0x2000/ Time Slot A Channel 1 ADC offset
	ADPD_write_reg(0x19 ,0x3FFF);	// reset: 0x2000/ Time Slot A Channel 2 ADC offset
	ADPD_write_reg(0x1A ,0x3FFF);	// reset: 0x2000/ Time Slot A Channel 3 ADC offset
	ADPD_write_reg(0x1B ,0x3FFF);	// reset: 0x2000/ Time Slot A Channel 4 ADC offset
	ADPD_write_reg(0x1E ,0x1F00);	// reset: 0x2000/ Time Slot B Channel 1 ADC offset
	ADPD_write_reg(0x1F ,0x3FFF);	// reset: 0x2000/ Time Slot B Channel 2 ADC offset
	ADPD_write_reg(0x20 ,0x3FFF);	// reset: 0x2000/ Time Slot B Channel 3 ADC offset
	ADPD_write_reg(0x21 ,0x3FFF);	// reset: 0x2000/ Time Slot B Channel 4 ADC offset
	ADPD_write_reg(0x22 ,0x3031);	// reset: 0x3000/ setting led3
	ADPD_write_reg(0x23 ,0x3033);	// reset: 0x3000/ setting led1
	ADPD_write_reg(0x24 ,0x3031);	// reset: 0x3000/ setting led2
	ADPD_write_reg(0x25 ,0x6317);	// reset: 0x630c/ led fine adjust -> led1:10111, led2: 01100(default), led3: 01100(default)
	ADPD_write_reg(0x30 ,0x0319);	// reset: 0x0320/ led pulse width (microseconds) and offset width (microseconds) -> time slot a
	ADPD_write_reg(0x31 ,0x0810);	// reset: 0x0818/ led pulse count and pulse period (microseconds) -> time slot a
	ADPD_write_reg(0x35 ,0x0319);	// reset: 0x0320/ led pulse width (microseconds) and offset width (microseconds) -> time slot b
	ADPD_write_reg(0x36 ,0x0810);	// reset: 0x0818/ led pulse count and pulse period (microseconds) -> time slot b
	ADPD_write_reg(0x39 ,0x2203);	// reset: 0x22fc/ afe width+offset time slot a
	ADPD_write_reg(0x3B ,0x2203);	// reset: 0x22fc/ afe width+offset time slot b
	ADPD_write_reg(0x3C ,0x31C6);	// reset: 0x3006/voltage cathode:1,8 V/afe channel power down -> power down ch2,ch3,ch4 from bpf amp and integrator op amp
	ADPD_write_reg(0x4B ,0x269C);	// reset: 0x2612/ clk32k normal operation, adjust
	ADPD_write_reg(0x4D ,0x0082);	// reset: 0x0098/ clk32m adjust

	ADPD_write_reg(0x10,0x0002);	//operating mode -> normal operating
}

void ADPD_write_reg(unsigned char reg_addr,unsigned short data){
	I2C_start(I2C_BASE,0x64,0); 		// send start and slave address + write
	I2C_write(I2C_BASE,reg_addr,0);  	// send register address
	I2C_write(I2C_BASE,data>>8,0);		// send data byte[15:8]
	I2C_write(I2C_BASE,data,1);		// send data byte[7:0]
}

void ADPD_read_reg8(unsigned char reg_addr, int *data){
	I2C_start(I2C_BASE,0x64,0); 		// send start and slave address + write
	I2C_write(I2C_BASE,reg_addr,0); 	// send register address
	I2C_start(I2C_BASE,0x64,1); 		// send start and slave address + read
	I2C_read(I2C_BASE,0);
	*data=I2C_read(I2C_BASE,1);			// read data byte[7:0]
}

void ADPD_read_reg16(unsigned char reg_addr, int *data){
	I2C_start(I2C_BASE,0x64,0); 		// send start and slave address + write
	I2C_write(I2C_BASE,reg_addr,0); 	// send register address
	I2C_start(I2C_BASE,0x64,1); 		// send start and slave address + read
	*data=I2C_read(I2C_BASE,0)<<8;		// read data byte[15:8]
	*data+=I2C_read(I2C_BASE,1);		// read data byte[7:0]
}

void ADPD_read_fifo(unsigned char reg_addr,int *slot_a,int *slot_b){

	I2C_start(I2C_BASE,0x64,0); 		// send start and slave address + write
	I2C_write(I2C_BASE,reg_addr,0); 	// send register address
	I2C_start(I2C_BASE,0x64,1); 		// send start and slave address + read
	*slot_a=(I2C_read(I2C_BASE,0))<<8;	// read slot_a byte[15:8]
	*slot_a+=I2C_read(I2C_BASE,0);		// read slot_a byte[7:0]
	*slot_b=I2C_read(I2C_BASE,0)<<8;	// read slot_b byte[15:8]
	*slot_b+=I2C_read(I2C_BASE,1);		// read slot_b byte[7:0]

}
