/*
 * test_board
 *
 * main.c
 *
 */


#include <system.h>
#include "unistd.h"

#include "sys/alt_stdio.h"
#include "altera_avalon_fifo_regs.h"
#include "altera_avalon_pio_regs.h"

int main()
{
	int array[1024],r;
	register int i;
	unsigned end_ptr;
	register unsigned int ptr __asm__("r16");
	register unsigned int fifobase __asm__("r17");
	register unsigned int val1 __asm__("r18");
	register unsigned int val2 __asm__("r19");
	register unsigned int numnibble __asm__("r20")=5;

	char c, b, gain, span=0, hiz=0, init=1;

	IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x04+0x08);	// adc_pwr, g0, g1, g2 -> set gain=1 and adc_pwr1_en=1
	IOWR_8DIRECT(ADAQ4003_BASE,0,0x01);	// span compression (2),high-Z mode (1), init (0) - adaq4003

	fifobase = FIFO_BASE;
	ptr = 0x800000;

	while (1)
	{
  	    c = *(volatile int*) (FIN_BASE);
  	    switch (c){
			// return 1024 values
			case '*': end_ptr = ptr + (16*1024*4); //end_ptr = ptr + (1024*4);
				do {asm("ldw r18,0(r16); custom 0,r18,r18,r20; addi r16,r16,4;");} while (ptr < end_ptr); break;

			case 't': fifobase = FIFO_BASE; ptr = 0x800000;
				// clear fifo
				do {asm("ldw r3,0(r17); ldw r3,0(r17); ldw r3,0(r17); ldw r3,0(r17);");
					ptr += 16;
				} while (ptr < 0x800810); // match the FIFO length!!! 512 + 4
				// capture a junk
				ptr = 0x800000;
				do {asm(	"ldw r3,0(r17);"					"stw r3,0(r16);"
							"ldw r3,0(r17);"					"stw r3,4(r16);"
							"ldw r3,0(r17);"					"stw r3,8(r16);"
							"ldw r3,0(r17);"					"stw r3,12(r16);"
							"ldw r3,0(r17);"					"stw r3,16(r16);"
							"ldw r3,0(r17);"					"stw r3,20(r16);"
							"ldw r3,0(r17);"					"stw r3,24(r16);"
							"ldw r3,0(r17);"					"stw r3,28(r16);"
							"ldw r3,0(r17);"					"stw r3,32(r16);"
							"ldw r3,0(r17);"					"stw r3,36(r16);"
							"ldw r3,0(r17);"					"stw r3,40(r16);"
							"ldw r3,0(r17);"					"stw r3,44(r16);"
							"ldw r3,0(r17);"					"stw r3,48(r16);"
							"ldw r3,0(r17);"					"stw r3,52(r16);"
							"ldw r3,0(r17);"					"stw r3,56(r16);"
							"ldw r3,0(r17);"					"stw r3,60(r16);"
					);
					ptr = ptr + 64;
				} while (ptr < 0xC00000);
				//} while (ptr < 0x808000);
				ptr = 0x800000;	break;

			// return 128 values
			case '+': for (i=0;i<128;i++){asm("ldw r18,0(r16); custom 0,r18,r18,r20; addi r16,r16,4;");} break;

			case 'r': fifobase = FIFO_BASE; r = 0;
					  do {asm("ldw r3,0(r17);");  r++;} while (r < (514)); // match the FIFO length!!! 512 + 2
					  asm("ldw r18,0(r17); custom 0,r18,r18,r20;");	break;
			// return 1 value
			case '.': asm("ldw r18,0(r16); custom 0,r18,r18,r20; addi r16,r16,4;"); break;

			case '?': val1=4; val2=1; asm("custom 0,r18,r18,r19;"); break;

			case '%': for (i=0;i<1024;i++){
						array[i] = *(volatile int*)
						(ptr)&0xFFFFF;
						ptr += 4;
					  }
					for (i=0;i<1024;i++){ val1=array[i]; asm("custom 0,r18,r18,r20;"); } break;

			case 'z': ptr = 0x800000;
					  do {val1 = 0x12345; asm("custom 0,r18,r18,r20;"); ptr += 4;} while (ptr < 0x800400);
					  ptr = 0x800000;	break;

			case 'x': ptr = 0x800000;
					do {*(volatile int*) (ptr) = 0x12345; ptr += 4;} while (ptr < 0xC00000);
					ptr = 0x800000; break;

			case 'y': ptr = 0x800000; i = 0;
					do {*(volatile int*) (ptr) = i; i ++; ptr += 4; } while (ptr < 0xC00000);
					ptr = 0x800000;	break;

			// g0, g1, g2
			case '0': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x07+0x08); break; // shutdown amplifier
			case '1': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x06+0x08);	break; // gain=0.25
			case '2': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x05+0x08);	break; // gain=0.5
			case '3': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x04+0x08); break; // gain=1
			case '4': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x03+0x08); break; // gain=2
			case '5': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x02+0x08); break; // gain=4
			case '6': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x01+0x08); break; // gain=8
			case '7': IOWR_ALTERA_AVALON_PIO_DATA(GPO_ADC_BASE, 0x00+0x08); break; // gain=16


			// span compression (2),high-Z mode (1), init (0) - adaq4003
			case 'S': span = 4; IOWR_8DIRECT(ADAQ4003_BASE,0,span+hiz+init);	break;
			case 's': span = 0; IOWR_8DIRECT(ADAQ4003_BASE,0,hiz+init);			break;
			case 'H': hiz  = 2; IOWR_8DIRECT(ADAQ4003_BASE,0,hiz+span+init);	break;
			case 'h': hiz  = 0; IOWR_8DIRECT(ADAQ4003_BASE,0,span+init);		break;

			// enable 10khz clk at pins D5 and D6(D5 -> inverted)
			case 'F': IOWR_ALTERA_AVALON_PIO_DATA(PIO_TEST_BASE,0x01);  	break;
			case 'f': IOWR_ALTERA_AVALON_PIO_DATA(PIO_TEST_BASE,0x00);  	break;

			// 'a' and 'b' -> reserved.
			case 'a': break;
			case 'b': break;

		}
	}

	return 0;
}
