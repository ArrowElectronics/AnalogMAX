/*
 * test_board
 *
 * main.c
 *
 */


#include <system.h>
#include "unistd.h"

#include "sys/alt_stdio.h"
#include "altera_avalon_fifo_regs.h"
#include "altera_avalon_pio_regs.h"


void printhex (unsigned int val, int numnibble )
{
	register unsigned int tx __asm__("r30")=val;
	register unsigned int length __asm__("r31") = numnibble;

	asm(
				"custom	0,r30,r30,r31;"
		);
}

#define ALT_CI_SRL4_N 0x00
#define ALT_CI_SRL4(A) __builtin_custom_ini(ALT_CI_SRL4_N,(A))


int main()
{
	int array[1024],r;
	register int i;
	unsigned end_ptr;
	register unsigned int ptr __asm__("r16");
	register unsigned int fifobase __asm__("r17");
	register unsigned int val __asm__("r18");
	register unsigned int numnibble __asm__("r19")=4;

	char c;

	IOWR_ALTERA_AVALON_PIO_DATA(ADC_GPO_BASE, 0xFF);	// adc_pwr, amplification
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_TEST_BASE,0x00);	// default: test disable
	IOWR_ALTERA_AVALON_PIO_DATA(ADAQ798X_BASE,0x7980);	// set adc to adaq7980 (1msps) for board variant C8B

	fifobase = FIN_ADC_BASE;
	ptr = 0x800000;

	while (1)
	{
  	    c = *(volatile int*) (FIN_FT245_BASE);

  	    switch (c){
			// return 1024 values
			case '*': end_ptr = ptr + (16*1024*4); //end_ptr = ptr + (1024*4);
				do {asm("ldw r18,0(r16); custom 0,r18,r18,r19; addi r16,r16,4;");} while (ptr < end_ptr); break;

			case 't': fifobase = FIN_ADC_BASE; ptr = 0x800000;
				// clear fifo
				do {asm("ldw r3,0(r17); ldw r3,0(r17); ldw r3,0(r17); ldw r3,0(r17);");
					ptr += 16;
				} while (ptr < 0x800810); // match the FIFO length!!! 512 + 4
				// capture a junk
				ptr = 0x800000;
				do {asm(	"ldw r3,0(r17);"					"stw r3,0(r16);"
							"ldw r3,0(r17);"					"stw r3,4(r16);"
							"ldw r3,0(r17);"					"stw r3,8(r16);"
							"ldw r3,0(r17);"					"stw r3,12(r16);"
							"ldw r3,0(r17);"					"stw r3,16(r16);"
							"ldw r3,0(r17);"					"stw r3,20(r16);"
							"ldw r3,0(r17);"					"stw r3,24(r16);"
							"ldw r3,0(r17);"					"stw r3,28(r16);"
							"ldw r3,0(r17);"					"stw r3,32(r16);"
							"ldw r3,0(r17);"					"stw r3,36(r16);"
							"ldw r3,0(r17);"					"stw r3,40(r16);"
							"ldw r3,0(r17);"					"stw r3,44(r16);"
							"ldw r3,0(r17);"					"stw r3,48(r16);"
							"ldw r3,0(r17);"					"stw r3,52(r16);"
							"ldw r3,0(r17);"					"stw r3,56(r16);"
							"ldw r3,0(r17);"					"stw r3,60(r16);"
					);
					ptr = ptr + 64;
				} while (ptr < 0xC00000);
				//} while (ptr < 0x808000);
				ptr = 0x800000;	break;

			// return 128 values
			case '+': for (i=0;i<128;i++){asm("ldw r18,0(r16); custom 0,r18,r18,r19; addi r16,r16,4;");} break;

			case 'r': fifobase = FIN_ADC_BASE; r = 0;
					  do {asm("ldw r3,0(r17);");  r++;} while (r < (514)); // match the FIFO length!!! 512 + 2
					  asm("ldw r18,0(r17); custom 0,r18,r18,r19;");	break;
			// return 1 value
			case '.': asm("ldw r18,0(r16); custom 0,r18,r18,r19; addi r16,r16,4;"); break;

			case '?': printhex(0x03, 1);	break;

			case '%': for (i=0;i<1024;i++){
						array[i] = *(volatile int*)
						(ptr)&0xFFFF;
						ptr += 4;
					  }
					for (i=0;i<1024;i++){
						printhex(array[i], 4);
					}		break;

			case 'z': ptr = 0x800000;
					  do {val = 0x1234; asm("custom 0,r18,r18,r19;"); ptr += 4;} while (ptr < 0x800400);
					  ptr = 0x800000;	break;

			case 'x': ptr = 0x800000;
					do {*(volatile int*) (ptr) = 0x1234; ptr += 4;} while (ptr < 0xC00000);
					ptr = 0x800000; break;

			case 'y': ptr = 0x800000; i = 0;
					do {*(volatile int*) (ptr) = i; i ++; ptr += 4; } while (ptr < 0xC00000);
					ptr = 0x800000;	break;

			// select amplification
			case '1': IOWR_ALTERA_AVALON_PIO_DATA(ADC_GPO_BASE, 4);  		break;
			case '2': IOWR_ALTERA_AVALON_PIO_DATA(ADC_GPO_BASE, 5);  		break;
			case '4': IOWR_ALTERA_AVALON_PIO_DATA(ADC_GPO_BASE, 6);			break;
			case '8': IOWR_ALTERA_AVALON_PIO_DATA(ADC_GPO_BASE, 7);  		break;

			// select board variant C8A  (adaq7988 - 500ksps) or C8B (adaq7980 - 1Msps)
			//case 'a': IOWR_ALTERA_AVALON_PIO_DATA(ADAQ798X_BASE,0x7988); 	break;
			case 'b': IOWR_ALTERA_AVALON_PIO_DATA(ADAQ798X_BASE,0x7980); 	break;

			// enable 10khz clk at pins D5 and D6(D5 -> inverted)
			case 'F': IOWR_ALTERA_AVALON_PIO_DATA(PIO_TEST_BASE,0x01);  	break;
			case 'f': IOWR_ALTERA_AVALON_PIO_DATA(PIO_TEST_BASE,0x00);  	break;
		}
	}

	return 0;
}
